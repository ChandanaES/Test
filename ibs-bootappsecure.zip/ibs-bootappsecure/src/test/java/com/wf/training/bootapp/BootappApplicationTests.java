package com.wf.training.bootapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootappApplicationTests {

	@Test
	void contextLoads() {
	}

}
