package com.wf.ibs.bootappsecure.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wf.ibs.bootappsecure.entity.Accounts;

public interface AccountsRepository extends JpaRepository<Accounts, Long>{

}
