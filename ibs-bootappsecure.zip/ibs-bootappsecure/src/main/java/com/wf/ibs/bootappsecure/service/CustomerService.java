package com.wf.ibs.bootappsecure.service;

import com.wf.ibs.bootappsecure.dto.AdminKycIdOutputDto;
import com.wf.ibs.bootappsecure.dto.CustomerOutputDto;
import com.wf.ibs.bootappsecure.dto.IBSResetPwdInputDto;
import com.wf.ibs.bootappsecure.dto.KycDetailsOutputDto;
import com.wf.ibs.bootappsecure.dto.ServiceProviderInputDto;
import com.wf.ibs.bootappsecure.dto.ServiceProviderOutputDto;

public interface CustomerService {

	public AdminKycIdOutputDto saveCustDetails(KycDetailsOutputDto kycUpdatedOutputDto);
	public CustomerOutputDto fetchSingleCustomer(Long uci);
	public CustomerOutputDto updatePwd(Long uci, IBSResetPwdInputDto resetPwdInputDto);
	
}
