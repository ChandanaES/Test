package com.wf.ibs.bootappsecure.repository;

import java.util.List;

import com.wf.ibs.bootappsecure.entity.Kyc;

public interface KycRepositoryCustom {

	//List<Kyc> veryComplexBusinessLogicReq(String email);
}
