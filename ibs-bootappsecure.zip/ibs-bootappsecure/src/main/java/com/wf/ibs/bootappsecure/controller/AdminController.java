package com.wf.ibs.bootappsecure.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wf.ibs.bootappsecure.dto.AdminKycIdInputDto;
import com.wf.ibs.bootappsecure.dto.AdminKycIdOutputDto;
import com.wf.ibs.bootappsecure.dto.CustomerOutputDto;
import com.wf.ibs.bootappsecure.dto.KycDetailsInputDto;
import com.wf.ibs.bootappsecure.dto.KycDetailsOutputDto;
import com.wf.ibs.bootappsecure.dto.ServiceProviderOutputDto;
import com.wf.ibs.bootappsecure.service.CustomerService;
import com.wf.ibs.bootappsecure.service.KycService;


@RequestMapping("/admin")
@Controller
public class AdminController {
	
	// add dependency
	@Autowired
	private KycService kycService;
	@Autowired
	private CustomerService custService;
		
	@RequestMapping("/home")
	public String adminHome() {
		
		return "admin-home";			
	}
	
		
	@RequestMapping(value="/getkyc-details", method=RequestMethod.GET)
	public String getKycDetails(Model model) {
		AdminKycIdInputDto kycInputDto = new AdminKycIdInputDto();
		model.addAttribute("getKycDetails", kycInputDto);
		return "getKyc-details";			
		
	}
	
	//display KYC - approve KYC
	@PostMapping("/getkyc-details")
	public String editKyc(@Valid @ModelAttribute("getKycDetails") AdminKycIdInputDto kycInputDto,
								  BindingResult result, Model model) {
		if(result.hasErrors()) {
			// throw custom exception
			//throw new IbsKycException("Invalid Data Format!");
			return "getKyc-details";
		}
		
		KycDetailsOutputDto kycOutputDto = this.kycService.fetchSingleKycDetails(kycInputDto.getKycId());
		model.addAttribute("getKycDetails", kycOutputDto);
		return "admin-editKyc";
	}
	
	//update KYC status
	@RequestMapping("/update-kycStatus")
	public String updatekycStatus(@ModelAttribute("getKycDetails") KycDetailsOutputDto kycOutputDto, 
								Model model) {
		KycDetailsOutputDto kycUpdatedOutputDto = this.kycService.updateKyc(kycOutputDto.getKycId(), 
													kycOutputDto);
		//If KYC Approved, UCI and sys password will be generated
		if ((kycUpdatedOutputDto.getKycStatus()).equalsIgnoreCase("Approve")) {
			AdminKycIdOutputDto adminKycIdOutputDto = this.custService.saveCustDetails(kycUpdatedOutputDto);
			model.addAttribute("kycUciDetails", adminKycIdOutputDto);
			return "admin-kycApproveConfirm";	
		}
		model.addAttribute("kycDetails", kycUpdatedOutputDto);
		return "admin-kycDeclineConfirm";			
		
	}

}
