package com.wf.ibs.bootappsecure.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;


public class CustomerInputDto {

	@NotNull(message="UCI is required")
	//@Pattern(regexp="^[0-9_]*$", message="UCI ID allows numbers only")
	private Long uci;
	
	@NotBlank(message="Password is required")
	@Pattern(regexp="[A-Za-z0-9_]*$", message="Password allows alphanumeric characters only")
	private String password;
	
	private String userType;
				
	public Long getUci() {
		return uci;
	}
	public void setUci(Long uci) {
		this.uci = uci;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	
}
