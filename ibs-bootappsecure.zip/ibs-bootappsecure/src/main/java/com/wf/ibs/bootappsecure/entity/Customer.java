package com.wf.ibs.bootappsecure.entity;

import java.util.UUID;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Customer {

	@Id  // primary key
	//@GeneratedValue(strategy = GenerationType.IDENTITY) // unique AI value 
	private Long uci;
	
	private String sysPassword;
	private String newPassword;
	
	//KycId as foreign key
	@OneToOne(mappedBy="customer")
	private Kyc kycId;
	
	public Long getUci() {
		return uci;
	}
	public void setUci(Long uci) {
		this.uci = uci;
	}
	public String getSysPassword() {
		return sysPassword;
	}
	public void setSysPassword(String sysPassword) {
		String temp=UUID.randomUUID().toString();
		sysPassword=temp.replace("-", "");
		this.sysPassword = sysPassword;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public Kyc getKycId() {
		return kycId;
	}
	public void setKycId(Kyc kycId) {
		this.kycId = kycId;
	}
	
	
	
	
	
}
