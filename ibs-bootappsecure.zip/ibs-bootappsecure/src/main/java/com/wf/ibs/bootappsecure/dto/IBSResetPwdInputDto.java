package com.wf.ibs.bootappsecure.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class IBSResetPwdInputDto {

	@NotNull(message="UCI is required")
	//@Pattern(regexp="^[0-9_]*$", message="UCI ID allows numbers only")
	private Long uci;
	
	@NotBlank(message="Current Password is required")
	@Pattern(regexp="[A-Za-z0-9_]*$", message="Password allows alphanumeric characters only")
	private String currentPassword;
	
	@NotBlank(message="New Password is required")
	@Pattern(regexp="[A-Za-z0-9_]*$", message="Password allows alphanumeric characters only")
	private String newPassword;

	public Long getUci() {
		return uci;
	}

	public void setUci(Long uci) {
		this.uci = uci;
	}

	public String getCurrentPassword() {
		return currentPassword;
	}

	public void setCurrentPassword(String currentPassword) {
		this.currentPassword = currentPassword;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	
	
}
