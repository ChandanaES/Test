package com.wf.ibs.bootappsecure.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

public class CheckBalance {

	@NotBlank(message="Account Number is required")
	@Pattern(regexp="^[0-9_]*$", message="Account Number allows numbers only")
	@Min(value=16, message="Enter 16 digit Account Number")
	private String accountNumber;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
}
