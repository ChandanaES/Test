package com.wf.ibs.bootappsecure.service;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wf.ibs.bootappsecure.dto.AccountsInputDto;
import com.wf.ibs.bootappsecure.dto.AccountsOutputDto;
import com.wf.ibs.bootappsecure.entity.Accounts;
import com.wf.ibs.bootappsecure.repository.AccountsRepository;
import com.wf.ibs.bootappsecure.repository.CustomerRepository;

@Service
public class AccountsServiceImpl implements AccountsService{

	//injecting a dependency
	@Autowired
	private CustomerRepository custRepository;
	@Autowired
	private AccountsRepository acctsRepository;
	
	
	//utility method
	private Accounts convertInputDtoToEntity(AccountsInputDto acctsInputDto) {
		Accounts accts = new Accounts();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date currentDate = new Date();
		//String dateCreated = dateFormat.format(currentDate);
		
		accts.setUci(acctsInputDto.getUci());
		accts.setAccountType(acctsInputDto.getAccountType());
		accts.setDateCreated(currentDate);
		accts.setStatus("Active");
					
		return accts;
	}
	
	// utility method
	private AccountsOutputDto convertEntityToOutputDto(Accounts accts) {
		AccountsOutputDto acctsOutputDto = new AccountsOutputDto();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		acctsOutputDto.setUci(accts.getUci());
		acctsOutputDto.setAccountType(accts.getAccountType());
		acctsOutputDto.setAccountNum(accts.getAccountNum());
		acctsOutputDto.setBalance(accts.getBalance());
		acctsOutputDto.setDateCreated(dateFormat.format(accts.getDateCreated()));
		acctsOutputDto.setStatus(accts.getStatus());
		
		return acctsOutputDto;
	}
		
	@Override
	public AccountsOutputDto saveAcctDetails(AccountsInputDto acctsInputDto) {
		if(this.custRepository.existsById(acctsInputDto.getUci())) {
		// convert dto into entity
		Accounts accts = this.convertInputDtoToEntity(acctsInputDto);
		// save into DB, returns newly added record
		Accounts newAccts = this.acctsRepository.save(accts);
		// convert entity into dto
		AccountsOutputDto acctsOutputDto = this.convertEntityToOutputDto(newAccts);
		return acctsOutputDto;
		}
		return null;
	}

}
