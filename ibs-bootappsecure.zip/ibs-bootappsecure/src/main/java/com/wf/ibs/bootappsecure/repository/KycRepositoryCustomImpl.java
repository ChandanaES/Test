package com.wf.ibs.bootappsecure.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;

import com.wf.ibs.bootappsecure.entity.Kyc;

public class KycRepositoryCustomImpl implements KycRepositoryCustom{

	// special bean exposed by JPA for custom DB interaction
		@Autowired
		private EntityManager entityManager;
		
		/*@Override
		public List<Kyc> veryComplexBusinessLogicReq(String email) {
			// entityManager.
			return null;
		}*/
}
