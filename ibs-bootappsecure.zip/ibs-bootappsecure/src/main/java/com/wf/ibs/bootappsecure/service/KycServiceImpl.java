package com.wf.ibs.bootappsecure.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wf.ibs.bootappsecure.dto.CustomerOutputDto;
import com.wf.ibs.bootappsecure.dto.KycDetailsInputDto;
import com.wf.ibs.bootappsecure.dto.KycDetailsOutputDto;
import com.wf.ibs.bootappsecure.entity.Customer;
import com.wf.ibs.bootappsecure.entity.Kyc;
import com.wf.ibs.bootappsecure.repository.KycRepository;

@Service
public class KycServiceImpl implements KycService{

	//injecting a dependency
	@Autowired
	private KycRepository repository;
	
	// utility method
	private KycDetailsOutputDto convertEntityToOutputDto(Kyc kyc) {
		KycDetailsOutputDto kycDetailsOutputDto = new KycDetailsOutputDto();
		
		kycDetailsOutputDto.setKycId(kyc.getKycId());
		kycDetailsOutputDto.setFirstName(kyc.getFirstName());
		kycDetailsOutputDto.setLastName(kyc.getLastName());
		kycDetailsOutputDto.setEmailID(kyc.getEmailID());
		kycDetailsOutputDto.setContactNumber(kyc.getContactNumber());
		kycDetailsOutputDto.setNationalIDType(kyc.getNationalIDType());
		kycDetailsOutputDto.setNationalIDNum(kyc.getNationalIDNum());
		kycDetailsOutputDto.setKycStatus(kyc.getKycStatus());
		
		/*EmployeeOutputDto employeeOutputDto = new EmployeeOutputDto();
		employeeOutputDto.setId(employee.getId());
		employeeOutputDto.setName(employee.getName());
		employeeOutputDto.setEmail(employee.getEmail());
		employeeOutputDto.setContact(employee.getContact());
		Double netSalary = employee.getBasicPay() +
						   employee.getHra() + 
						   employee.getTa() + 
						   employee.getDa() -
						   employee.getPfDeduction();
		employeeOutputDto.setNetSalary(netSalary);*/
		return kycDetailsOutputDto;
	}
	
	//utility method
	private Kyc convertInputDtoToEntity(KycDetailsInputDto kycDetailsInputDto) {
		Kyc kyc = new Kyc();
		kyc.setFirstName(kycDetailsInputDto.getFirstName());
		kyc.setLastName(kycDetailsInputDto.getLastName());
		kyc.setEmailID(kycDetailsInputDto.getEmailID());
		kyc.setContactNumber(kycDetailsInputDto.getContactNumber());
		kyc.setNationalIDType(kycDetailsInputDto.getNationalIDType());
		kyc.setNationalIDNum(kycDetailsInputDto.getNationalIDNum());
		kyc.setKycStatus("Submitted");		
		return kyc;
	}
	
	//utility method
	private Kyc convertOutputDtoToEntity(KycDetailsOutputDto kycOutputDto) {
		Kyc kyc = new Kyc();
		kyc.setKycId(kycOutputDto.getKycId());
		kyc.setFirstName(kycOutputDto.getFirstName());
		kyc.setLastName(kycOutputDto.getLastName());
		kyc.setEmailID(kycOutputDto.getEmailID());
		kyc.setContactNumber(kycOutputDto.getContactNumber());
		kyc.setNationalIDType(kycOutputDto.getNationalIDType());
		kyc.setNationalIDNum(kycOutputDto.getNationalIDNum());
		kyc.setKycStatus(kycOutputDto.getKycStatus());		
		return kyc;
	}
	
	@Override
	public KycDetailsOutputDto fetchSingleKycDetails(Long KycId) {
		if(this.repository.existsById(KycId)) {
			Kyc kyc = this.repository.findById(KycId).orElse(null);
			KycDetailsOutputDto kycDetailsOutputDto = this.convertEntityToOutputDto(kyc);
			return kycDetailsOutputDto;
		}
		return null;
	}
	
	@Override
	public KycDetailsOutputDto saveKycDetails(KycDetailsInputDto kycDetailsInputDto) {
		// convert dto into entity
		Kyc kyc = this.convertInputDtoToEntity(kycDetailsInputDto);
		// save into DB, returns newly added record
		Kyc newKyc = this.repository.save(kyc);
		// convert entity into dto
		KycDetailsOutputDto kycDetailsOutputDto =  this.convertEntityToOutputDto(newKyc);
		return kycDetailsOutputDto;
	}

	@Override
	public KycDetailsOutputDto updateKyc(Long KycId, KycDetailsOutputDto kycDetailsOutputDto) {
		if(this.repository.existsById(KycId)) {
			// convert input dto into entity
			Kyc kyc= this.convertOutputDtoToEntity(kycDetailsOutputDto);
			kyc.setKycId(KycId);
			Kyc newKyc = this.repository.save(kyc);
			KycDetailsOutputDto kycOutputDto = this.convertEntityToOutputDto(newKyc);
			return kycOutputDto;
			
		}
		return null;
	}
}
