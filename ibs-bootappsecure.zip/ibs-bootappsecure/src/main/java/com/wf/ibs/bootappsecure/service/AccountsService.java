package com.wf.ibs.bootappsecure.service;

import com.wf.ibs.bootappsecure.dto.AccountsInputDto;
import com.wf.ibs.bootappsecure.dto.AccountsOutputDto;

public interface AccountsService {

	public AccountsOutputDto saveAcctDetails(AccountsInputDto acctsInputDto);
}
