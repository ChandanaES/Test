package com.wf.ibs.bootappsecure.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

//map java class to db table
@Entity // by default class name is defined as table name
//@Table(name = "employeemaster")
public class Kyc {

	// all field will be mapped as cols with same name
	@Id  // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // unique AI value 
	private Long KycId;
	
	// @Column(name = "empname")
	private String firstName;
	
	private String lastName;
	private String contactNumber;
	private String emailID;
	private String nationalIDType;
	private String nationalIDNum;
	private String kycStatus;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="customer", referencedColumnName="KycId")
	private Customer customer;
	
	public Long getKycId() {
		return KycId;
	}
	public void setKycId(Long kycId) {
		KycId = kycId;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getNationalIDType() {
		return nationalIDType;
	}
	public void setNationalIDType(String nationalIDType) {
		this.nationalIDType = nationalIDType;
	}
	public String getNationalIDNum() {
		return nationalIDNum;
	}
	public void setNationalIDNum(String nationalIDNum) {
		this.nationalIDNum = nationalIDNum;
	}
	public String getKycStatus() {
		return kycStatus;
	}
	public void setKycStatus(String kycStatus) {
		this.kycStatus = kycStatus;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
}
