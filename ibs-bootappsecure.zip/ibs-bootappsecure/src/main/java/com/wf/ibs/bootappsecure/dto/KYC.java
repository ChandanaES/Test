package com.wf.ibs.bootappsecure.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

public class KYC {

	@NotBlank(message="User Name is required")
	@Pattern(regexp="^[A-Za-z0-9_]*$", message="Enter a valid User Name")
	private String username;
	
	@NotBlank(message="Password is required")
	@Pattern(regexp="^[A-Za-z0-9_]*$", message="Password allows alphanumeric characters only")
	private String password;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
