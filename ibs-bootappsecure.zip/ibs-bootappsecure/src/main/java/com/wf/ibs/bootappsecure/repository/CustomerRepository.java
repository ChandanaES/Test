package com.wf.ibs.bootappsecure.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wf.ibs.bootappsecure.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long>{

}
