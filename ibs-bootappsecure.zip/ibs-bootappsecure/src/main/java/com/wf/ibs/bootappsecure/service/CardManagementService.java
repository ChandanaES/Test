package com.wf.ibs.bootappsecure.service;

import java.util.List;

import com.wf.ibs.bootappsecure.dto.CardManagementInputDto;
import com.wf.ibs.bootappsecure.dto.CardManagementOutputDto;


public interface CardManagementService {

	public List<CardManagementOutputDto> fetchAllDetails();
	public CardManagementOutputDto fetchSingleDetail(Long id);
	public CardManagementOutputDto saveDetails(CardManagementInputDto cardManagementInputDto);
	public CardManagementOutputDto updateDetails(Long id, CardManagementInputDto cardManagementInputDto);
	public CardManagementOutputDto deleteDetails(Long id);
}
