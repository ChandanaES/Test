package com.wf.ibs.bootappsecure.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class KycDetailsInputDto {

	@NotBlank(message="First Name is required")
	private String firstName;
	
	@NotBlank(message="Last Name is required")
	private String lastName;
	
	@NotBlank(message="Contact Number is required")
	@Pattern(regexp="^[0-9_]*$", message="Contact Number allows numbers only")
	@Min(value=10, message="Contact Number allows 10 digits max")
	private String contactNumber;
	
	@NotBlank(message="Email ID is required")
	@Email(message="Enter email in valid format")
	private String emailID;
	
	@NotNull(message="National ID Type is required")
	private String nationalIDType;
	
	@NotBlank(message="National ID is required")
	private String nationalIDNum;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	
	public String getNationalIDType() {
		return nationalIDType;
	}
	public void setNationalIDType(String nationalIDType) {
		this.nationalIDType = nationalIDType;
	}
	public String getNationalIDNum() {
		return nationalIDNum;
	}
	public void setNationalIDNum(String nationalIDNum) {
		this.nationalIDNum = nationalIDNum;
	}
	
	/*public KycDetailsInputDto() {
		this.nationalIDType= new ArrayList<>(Arrays.asList("Aadhaar", "PAN","Passport","Driving License"));
		nationalIDType.add("Aadhaar");
		nationalIDType.add("PAN");
		nationalIDType.add("Passport");
		nationalIDType.add("Driving License");
	}	
		*/
	
}
