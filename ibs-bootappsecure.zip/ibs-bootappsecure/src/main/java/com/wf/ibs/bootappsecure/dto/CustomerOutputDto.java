package com.wf.ibs.bootappsecure.dto;

public class CustomerOutputDto {

	private Long uci;
	private String sysPassword;
	private String newPassword;
	public Long getUci() {
		return uci;
	}
	public void setUci(Long uci) {
		this.uci = uci;
	}
	public String getSysPassword() {
		return sysPassword;
	}
	public void setSysPassword(String sysPassword) {
		this.sysPassword = sysPassword;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	
	
}
