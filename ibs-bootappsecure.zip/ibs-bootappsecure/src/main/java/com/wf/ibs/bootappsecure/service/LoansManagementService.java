package com.wf.ibs.bootappsecure.service;

import java.util.List;

import com.wf.ibs.bootappsecure.dto.LoansManagementInputDto;
import com.wf.ibs.bootappsecure.dto.LoansManagementOutputDto;


public interface LoansManagementService {

	public List<LoansManagementOutputDto> fetchAllDetails();
	public LoansManagementOutputDto fetchSingleDetail(Long id);
	public LoansManagementOutputDto saveDetails(LoansManagementInputDto loansManagementInputDto);
	public LoansManagementOutputDto updateDetails(Long id, LoansManagementInputDto loansManagementInputDto);
	public LoansManagementOutputDto deleteDetails(Long id);
}
