package com.wf.ibs.bootappsecure.service;

import com.wf.ibs.bootappsecure.dto.ServiceProviderInputDto;
import com.wf.ibs.bootappsecure.dto.ServiceProviderOutputDto;

public interface SpService {

	public ServiceProviderOutputDto saveSpDetails(ServiceProviderInputDto spInputDto);
}
