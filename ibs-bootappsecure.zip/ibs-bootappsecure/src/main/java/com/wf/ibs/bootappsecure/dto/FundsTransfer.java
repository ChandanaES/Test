package com.wf.ibs.bootappsecure.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class FundsTransfer {

	private String beneficiary;
	
	@NotNull(message="Amount is required")
	private Integer transferAmount;
	
	@NotBlank(message="Description is required")
	@Pattern(regexp="^[A-Za-z0-9_]*$", message="Decription allows alphanumeric characters only")
	private String transferDescription;

	public String getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(String beneficiary) {
		this.beneficiary = beneficiary;
	}

	public Integer getTransferAmount() {
		return transferAmount;
	}

	public void setTransferAmount(Integer transferAmount) {
		this.transferAmount = transferAmount;
	}

	public String getTransferDescription() {
		return transferDescription;
	}

	public void setTransferDescription(String transferDescription) {
		this.transferDescription = transferDescription;
	}
}
