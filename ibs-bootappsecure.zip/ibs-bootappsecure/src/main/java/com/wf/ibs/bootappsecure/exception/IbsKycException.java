package com.wf.ibs.bootappsecure.exception;

public class IbsKycException extends RuntimeException{

	public IbsKycException(String message) {
		super(message);
	}
}
