package com.wf.ibs.bootappsecure.entity;



import java.util.Date;
import java.util.Random;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Accounts {

	@Id  // primary key
	private Long uci;
	
	private String accountType;
	
	//@GeneratedValue(strategy = GenerationType.IDENTITY) // unique AI value 
	private Long accountNum;
	
	private Double balance;
	
	private String status;
	
	private Date dateCreated;

	public Long getUci() {
		return uci;
	}

	public void setUci(Long uci) {
		this.uci = uci;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Long getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(Long accountNum) {
		Random rand = new Random();
		long accountNumRand = (rand.nextLong())+300000000;
		//String accountNum = Integer.toString(randomNum);
		accountNum=accountNumRand;
		this.accountNum = accountNum;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	} 
	
}
