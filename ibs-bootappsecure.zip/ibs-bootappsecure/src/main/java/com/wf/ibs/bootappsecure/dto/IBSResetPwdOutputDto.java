package com.wf.ibs.bootappsecure.dto;


public class IBSResetPwdOutputDto {

	private Long uci;
	
	/*@NotBlank(message="Current Password is required")
	@Pattern(regexp="[A-Za-z0-9_]*$", message="Password allows alphanumeric characters only")
	private String currentPassword;*/
	
	
	private String newPassword;

	public Long getUci() {
		return uci;
	}

	public void setUci(Long uci) {
		this.uci = uci;
	}

	/*public String getCurrentPassword() {
		return currentPassword;
	}

	public void setCurrentPassword(String currentPassword) {
		this.currentPassword = currentPassword;
	}*/

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	
	
}
