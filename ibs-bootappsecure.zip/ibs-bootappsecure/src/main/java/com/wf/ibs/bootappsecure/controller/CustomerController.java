package com.wf.ibs.bootappsecure.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wf.ibs.bootappsecure.dto.*;
import com.wf.ibs.bootappsecure.service.AccountsService;
import com.wf.ibs.bootappsecure.service.BeneficiaryService;
import com.wf.ibs.bootappsecure.service.CardManagementService;
import com.wf.ibs.bootappsecure.service.CustomerService;
import com.wf.ibs.bootappsecure.service.LoansManagementService;
import com.wf.ibs.bootappsecure.service.SpService;

@RequestMapping("/customer")
@Controller
public class CustomerController {

	// add dependency
	@Autowired
	private SpService spService;
	@Autowired
	private CustomerService customerService;
	@Autowired
	private AccountsService acctsService;
	@Autowired
	private BeneficiaryService service;
	@Autowired
	private CardManagementService cardservice;
	@Autowired
	private LoansManagementService loansservice;
	
	@RequestMapping(value="/ibslogin", method=RequestMethod.GET)
	public String ibsLogin(Model model) {
		CustomerInputDto custInputDto = new CustomerInputDto();
		model.addAttribute("ibsLogin", custInputDto);
		return "ibs-login";
	}
	
		
	@RequestMapping(value="/ibslogin", method=RequestMethod.POST)
	public String ibsLoginValidate(@Valid @ModelAttribute("ibsLogin") CustomerInputDto custInputDto, 
									BindingResult result,
									Model model) {
		if (result.hasErrors()) 
			return "ibs-login";
		
		//Long uci = Long.parseLong(custInputDto.getUci());
		CustomerOutputDto custOutputDto = this.customerService.fetchSingleCustomer(custInputDto.getUci());
		
		if(custInputDto.getPassword().equals(custOutputDto.getNewPassword())) 
			return "ibs-home";
		
		if(custInputDto.getPassword().equals(custOutputDto.getSysPassword())) 
			return "redirect:/customer/reset-pwd";
		
		return "loginerror";
	}
	
	@RequestMapping(value="/reset-pwd", method=RequestMethod.GET)
	public String resetPwd(Model model) {
		IBSResetPwdInputDto resetPwdInputDto = new IBSResetPwdInputDto();
		model.addAttribute("resetPwd", resetPwdInputDto);
		return "ibs-resetpwd";			
		
	}
	
	@RequestMapping(value="/reset-pwd", method=RequestMethod.POST)
	public String resetPwdValidate(@Valid @ModelAttribute("resetPwd") IBSResetPwdInputDto resetPwdInputDto, 
									BindingResult result,
									Model model) {
		if (result.hasErrors()) 
			return "ibs-resetpwd";
		CustomerOutputDto custOutputDto = this.customerService.updatePwd(resetPwdInputDto.getUci(), 
											resetPwdInputDto);
		if(custOutputDto == null) {
			// throw custom exception
			//throw new EmployeeNotFoundException("Employee not found with Id : " + id);
			return "database-error";
		}
		
		return "ibs-resetpwdconfirm";
	}
	
	@RequestMapping(value="/home", method=RequestMethod.GET)
	public String ibsHome(Model model) {
		IBSHome ibsHome = new IBSHome();
		model.addAttribute("ibsHome", ibsHome);
		return "ibs-home";			
		
	}
	
	
	@RequestMapping("/acct-summary")
	public String acctSummary() {
		return "acct-summary";
	}
	
	@RequestMapping(value="/create-acct", method=RequestMethod.GET)
	public String acctCreate(Model model) {
		AccountsInputDto acctsInputDto = new AccountsInputDto();
		model.addAttribute("acctCreate", acctsInputDto);
		return "account-create";
	}
	
	@RequestMapping(value="/create-acct", method=RequestMethod.POST)
	public String acctCreateConfirm(@Valid @ModelAttribute("acctCreate") AccountsInputDto acctsInputDto, 
									BindingResult result,
									Model model) {
		
		if (result.hasErrors()) {
			return "account-create";
		}
		
		AccountsOutputDto acctsOutputDto = this.acctsService.saveAcctDetails(acctsInputDto);
		model.addAttribute("acctCreate", acctsOutputDto);
		return "account-confirm";
			
	}
	
	@RequestMapping(value="/check-balance", method=RequestMethod.GET)
	public String chkBalance(Model model) {
		CheckBalance chkBalance = new CheckBalance();
		model.addAttribute("chkBalance", chkBalance);
		return "check-balance";
	}
	
	@RequestMapping(value="/check-balance", method=RequestMethod.POST)
	public String chkBalanceConfirm(@Valid @ModelAttribute("chkBalance") CheckBalance chkBalance, BindingResult result) {
		
		if (result.hasErrors()) {
			return "check-balance";
		}
		else
			return "check-balance";
			
	}
	
	@RequestMapping(value="/request-stmt")
	public String requestStmt() {
		return "request-stmt";
	}
	
	@RequestMapping(value="/transfer-funds", method=RequestMethod.GET)
	public String transferFunds(Model model) {
		FundsTransfer fundsTransfer = new FundsTransfer();
		model.addAttribute("fundsTransfer", fundsTransfer);
		return "transfer-funds";
	}
	
	@RequestMapping(value="/transfer-funds", method=RequestMethod.POST)
	public String transferFundsSuccess(@Valid @ModelAttribute("fundsTransfer") FundsTransfer fundsTransfer, BindingResult result) {
		
		if (result.hasErrors()) {
			return "transfer-funds";
		}
		else
			return "fundTransfer-success";
			
	}
	@RequestMapping(value="/bill-payments", method=RequestMethod.GET)
	public String billPayments(Model model) {
		BillPayments billPayments = new BillPayments();
		model.addAttribute("billPayments", billPayments);
		return "bill-payments";
	}
	
	@RequestMapping(value="/bill-payments", method=RequestMethod.POST)
	public String billPaymentSuccess(@Valid @ModelAttribute("billPayments") BillPayments billPayments, BindingResult result) {
		
		if (result.hasErrors()) {
			return "bill-payments";
		}
		else
			return "billPayment-success";
	}
	
	@RequestMapping(value="/service-prov", method=RequestMethod.GET)
	public String serviceProviderEntry(Model model) {
		ServiceProviderInputDto serviceProv = new ServiceProviderInputDto();
		model.addAttribute("serviceProv", serviceProv);
		return "servProv-entry";
	}
	
	//Register Service Provider details
	@PostMapping(value="/service-prov")
	public String serviceProvConfirm(@Valid @ModelAttribute("serviceProv") ServiceProviderInputDto spInputDto,
									 BindingResult result,
									 Model model) {
		
		if (result.hasErrors()) {
			return "servProv-entry";
		}
		
		ServiceProviderOutputDto spOutputDto = this.spService.saveSpDetails(spInputDto);
		model.addAttribute("serviceProv", spOutputDto);
		return "servProv-confirm";
				
	}

	@RequestMapping("/beneficiaryhome") 
	public String beneficiaryhome(Model model) {
		BeneficiaryInputDto beneficiaryInputDto=new BeneficiaryInputDto();
		model.addAttribute("beneficiaryInputDto", beneficiaryInputDto);		
		return "beneficiary-home";
	}
	
	@RequestMapping("/addDetails") 
	public String addDetails(Model model) {
		BeneficiaryInputDto beneficiaryInputDto=new BeneficiaryInputDto();
		model.addAttribute("beneficiaryInputDto", beneficiaryInputDto);	
		return "beneficiary";
	}
	
	// @ModelAttribute will save param value into model object
		@RequestMapping("/Details")
		public String saveProfile(@Valid @ModelAttribute BeneficiaryInputDto beneficiaryInputDto,BindingResult result,Model model) {
			if(result.hasErrors()) {
				System.out.println(result);
				return "beneficiary";
			}
			service.saveDetails(beneficiaryInputDto);
			return "beneficiary-details";
		}
		
		@RequestMapping("/modifyDetails")
		public String modifyDetails(Model model) {
			BeneficiaryInputDto beneficiaryInputDto=new BeneficiaryInputDto();
			model.addAttribute("beneficiaryInputDto", beneficiaryInputDto);
			return "modifybeneficiary"; 
			}
		@RequestMapping("/saveDetails")
		public String saveDetails(@Valid @ModelAttribute BeneficiaryInputDto beneficiaryInputDto,BindingResult result,Model model,Long id) {
			if(result.hasErrors()) {
				System.out.println(result);
				return "modifybeneficiary";
			}
			service.updateDetails(id, beneficiaryInputDto);
			return "beneficiary-details";
		}
		
		@RequestMapping("/cardManagement") 
		public String cardManagement(Model model) {
			CardManagementInputDto cardManagementInputDto=new CardManagementInputDto();
			model.addAttribute("cardManagementInputDto", cardManagementInputDto);	
			return "CardManagement_CustomerLogin";
		}
		
		
		  @RequestMapping("/cardstatement")
		 public String cardstatement(Model model){ 
			  CardManagementInputDto cardManagementInputDto=new CardManagementInputDto();
				model.addAttribute("cardManagementInputDto", cardManagementInputDto);
		  return "Cardstatement"; 
		  }
		  
		  @RequestMapping("/loanManagement") 
			public String loanManagement(Model model) {
			  LoansManagementInputDto loansManagementInputDto=new LoansManagementInputDto();
				model.addAttribute("loansManagementInputDto", loansManagementInputDto);	
				return "Loans_CustomerLogin";
			}
		  
		  @RequestMapping("/saveLoanDetails")
			public String saveLoanDetails(@Valid @ModelAttribute LoansManagementInputDto loansManagementInputDto,BindingResult result) {
				if(result.hasErrors()) {
					System.out.println(result);
					return "Loans_CustomerLogin";
				}
				return "Cardstatement";
			}

}
