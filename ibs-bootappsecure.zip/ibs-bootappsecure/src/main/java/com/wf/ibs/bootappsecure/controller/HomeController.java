package com.wf.ibs.bootappsecure.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wf.ibs.bootappsecure.dto.CustomerInputDto;
import com.wf.ibs.bootappsecure.dto.KYCRegister;



//Shall contain processing logic
//Bean created
//Register with Handler Mapper
@Controller
public class HomeController {

	/*@RequestMapping(value="/", method=RequestMethod.GET)
	public String kycRegistration(Model model) {
		KYCRegister kycRegister = new KYCRegister();
		model.addAttribute("kycRegister", kycRegister);
		return "kyc-register";
	}
	
	@RequestMapping(value="/", method=RequestMethod.POST)
	public String kycRegisterValidate(@Valid @ModelAttribute("kycRegister") KYCRegister kycRegister, BindingResult result) {
		if (result.hasErrors()) {
			return "kyc-register";
		}
		else
			return "kyc-login";
	}*/
	
	@RequestMapping("/custom-login")
	public String customLogin() {
		/*IBSLogin ibsLogin = new IBSLogin();
		model.addAttribute("ibsLogin", ibsLogin);
		return "ibs-login";*/
		//return "redirect:/customer/login";
		return  "login-form";
	}
	
	// to respond to root URL
	@RequestMapping("/")
	public String home() {
		// add business logic
		
		// respond back with view page name
		return  "index";
	}
	
	/*@RequestMapping(value="/custom-login", method=RequestMethod.POST)
	public String ibsLoginValidate(@Valid @ModelAttribute("ibsLogin") IBSLogin ibsLogin, BindingResult result) {
		if (result.hasErrors()) {
			return "ibs-login";
		}
		else
			return "ibs-home";
	}*/
	
	@RequestMapping("/access-denied")
	public String accessDenied() {
		
		return "invalid-details";
	}
}
