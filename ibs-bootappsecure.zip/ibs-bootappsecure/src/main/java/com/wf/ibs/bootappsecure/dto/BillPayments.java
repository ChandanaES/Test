package com.wf.ibs.bootappsecure.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class BillPayments {

	private String billType;
	private String servProvider;
	
	@NotNull(message="Amount is required")
	private Integer billAmount;
	
	@NotBlank(message="Description is required")
	@Pattern(regexp="^[A-Za-z0-9_]*$", message="Decription allows alphanumeric characters only")
	private String billDescription;

	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	public String getServProvider() {
		return servProvider;
	}

	public void setServProvider(String servProvider) {
		this.servProvider = servProvider;
	}

	public Integer getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(Integer billAmount) {
		this.billAmount = billAmount;
	}

	public String getBillDescription() {
		return billDescription;
	}

	public void setBillDescription(String billDescription) {
		this.billDescription = billDescription;
	}
	
}
