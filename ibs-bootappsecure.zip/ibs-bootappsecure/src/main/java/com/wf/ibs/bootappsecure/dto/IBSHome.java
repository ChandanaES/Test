package com.wf.ibs.bootappsecure.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class IBSHome {

	@NotBlank(message="Account Number is required")
	@Pattern(regexp="^[0-9_]*$", message="Account Number allows numbers only")
	private String accountNumber;
	
	@NotNull(message="Amount is required")
	private Integer transferAmount;
	
	@NotBlank(message="Description is required")
	@Max(value = 50, message="Max 50 characters are allowed in Description")
	@Pattern(regexp="^[A-Za-z0-9_]*$", message="Decription allows alphanumeric characters only")
	private String transferDescription;

	@NotNull(message="Amount is required")
	private Integer billAmount;
	
	@NotBlank(message="Description is required")
	@Max(value = 50, message="Max 50 characters are allowed in Description")
	@Pattern(regexp="^[A-Za-z0-9_]*$", message="Decription allows alphanumeric characters only")
	private String billDescription;
	
	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Integer getTransferAmount() {
		return transferAmount;
	}

	public void setTransferAmount(Integer transferAmount) {
		this.transferAmount = transferAmount;
	}

	public String getTransferDescription() {
		return transferDescription;
	}

	public void setTransferDescription(String transferDescription) {
		this.transferDescription = transferDescription;
	}

	public Integer getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(Integer billAmount) {
		this.billAmount = billAmount;
	}

	public String getBillDescription() {
		return billDescription;
	}

	public void setBillDescription(String billDescription) {
		this.billDescription = billDescription;
	}

	
	
}
