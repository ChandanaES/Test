package com.wf.ibs.bootappsecure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootappSecureApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootappSecureApplication.class, args);
	}

}
