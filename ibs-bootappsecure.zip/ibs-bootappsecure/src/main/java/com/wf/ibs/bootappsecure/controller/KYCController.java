package com.wf.ibs.bootappsecure.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wf.ibs.bootappsecure.dto.KYC;
import com.wf.ibs.bootappsecure.dto.KycDetailsInputDto;
import com.wf.ibs.bootappsecure.dto.KYCRegister;
import com.wf.ibs.bootappsecure.dto.KycDetailsOutputDto;
import com.wf.ibs.bootappsecure.service.KycService;

@RequestMapping("/kyc")
@Controller
public class KYCController {
	
	// add dependency
	@Autowired
	private KycService service;
	
	@RequestMapping(value="/register", method=RequestMethod.GET)
	public String kycRegistration(Model model) {
		KYCRegister kycRegister = new KYCRegister();
		model.addAttribute("kycRegister", kycRegister);
		return "kyc-register";
	}
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public String kycRegisterValidate(@Valid @ModelAttribute("kycRegister") KYCRegister kycRegister, BindingResult result) {
		if (result.hasErrors()) {
			return "kyc-register";
		}
		else
			return "redirect:/kyc/login";
	}
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String kycLogin(Model model) {
		KYC kyc = new KYC();
		model.addAttribute("kyc", kyc);
		return "kyc-login";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String kycLoginValidate(@Valid @ModelAttribute("kyc") KYC kyc, BindingResult result) {
		//System.out.println(result);
		/*if (!(result.hasErrors())) {
			KYCDetails kycDetails = new KYCDetails();
			model.addAttribute("kycDetails", kycDetails);
			return "kyc-home";			
		}*/
			//return "invalid-details";
		if (result.hasErrors()) {
			/*redirectAttr.addFlashAttribute("org.springframework.validation.BindingResult.kyc", result);
			redirectAttr.addFlashAttribute("kyc", kyc);*/
			return "kyc-login";
		}
		else
			return "redirect:/kyc/entry";
				
	}

	
	@RequestMapping(value="/entry", method=RequestMethod.GET)
	public String kycEntry(Model model) {
		KycDetailsInputDto kycDetails = new KycDetailsInputDto();
		model.addAttribute("kycDetails", kycDetails);
		return "kyc-home";			
		
	}
	
	// add KYC details
	@PostMapping("/entry")
	public String saveKycDetails(@Valid @ModelAttribute KycDetailsInputDto kycDetailsInputDto,
								  BindingResult result, Model model) {
		if(result.hasErrors()) {
			// throw custom exception
			//throw new IbsKycException("Invalid Data Format!");
			return "kyc-home";
		}
		
		KycDetailsOutputDto kycDetailsOutputDto = this.service.saveKycDetails(kycDetailsInputDto);
		
		/*ResponseEntity<KycDetailsOutputDto> response =
				new ResponseEntity<KycDetailsOutputDto>(kycDetailsOutputDto, HttpStatus.OK);
		
		if (response.getStatusCodeValue()!=200)
			return "databse-error";*/
		
		model.addAttribute("kycDetails", kycDetailsOutputDto);
		return "kyc-confirm";
	}
		
}
