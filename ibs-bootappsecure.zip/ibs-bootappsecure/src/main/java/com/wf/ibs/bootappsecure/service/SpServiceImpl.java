package com.wf.ibs.bootappsecure.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wf.ibs.bootappsecure.dto.ServiceProviderInputDto;
import com.wf.ibs.bootappsecure.dto.ServiceProviderOutputDto;
import com.wf.ibs.bootappsecure.entity.ServiceProvider;
import com.wf.ibs.bootappsecure.repository.ServiceProviderRepository;

@Service
public class SpServiceImpl implements SpService {

	//injecting a dependency
	@Autowired
	private ServiceProviderRepository repository;
	
	//utility method
	private ServiceProvider convertInputDtoToEntity(ServiceProviderInputDto spInputDto) {
		ServiceProvider sp = new ServiceProvider();
		sp.setFirstName(spInputDto.getFirstName());
		sp.setLastName(spInputDto.getLastName());
		sp.setEmailID(spInputDto.getEmailID());
		sp.setContactNumber(spInputDto.getContactNumber());
		sp.setAccountNumber(spInputDto.getAccountNumber());
		sp.setBranchName(spInputDto.getBranchName());
		sp.setBranchAddress(spInputDto.getBranchAddress());
		sp.setIfscCode(spInputDto.getIfscCode());
		sp.setSpStatus("Submitted");
			
		return sp;
	}
	
	// utility method
	private ServiceProviderOutputDto convertEntityToOutputDto(ServiceProvider sp) {
		ServiceProviderOutputDto spOutputDto = new ServiceProviderOutputDto();
		
		spOutputDto.setSpId(sp.getSpId());
		spOutputDto.setFirstName(sp.getFirstName());
		spOutputDto.setLastName(sp.getLastName());
		spOutputDto.setEmailID(sp.getEmailID());
		spOutputDto.setContactNumber(sp.getContactNumber());
		spOutputDto.setAccountNumber(sp.getAccountNumber());
		spOutputDto.setBranchName(sp.getBranchName());
		spOutputDto.setBranchAddress(sp.getBranchAddress());
		spOutputDto.setIfscCode(sp.getIfscCode());
		spOutputDto.setSpStatus(sp.getSpStatus());
					
		return spOutputDto;
	}

	@Override
	public ServiceProviderOutputDto saveSpDetails(ServiceProviderInputDto spInputDto) {
		// convert dto into entity
		ServiceProvider sp = this.convertInputDtoToEntity(spInputDto);
		// save into DB, returns newly added record
		ServiceProvider newSp = this.repository.save(sp);
		// convert entity into dto
		ServiceProviderOutputDto spOutputDto =  this.convertEntityToOutputDto(newSp);
		return spOutputDto;
	}
}
