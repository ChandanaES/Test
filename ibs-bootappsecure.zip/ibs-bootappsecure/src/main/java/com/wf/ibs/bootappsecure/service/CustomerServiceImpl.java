package com.wf.ibs.bootappsecure.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wf.ibs.bootappsecure.dto.AdminKycIdOutputDto;
import com.wf.ibs.bootappsecure.dto.CustomerOutputDto;
import com.wf.ibs.bootappsecure.dto.IBSResetPwdInputDto;
import com.wf.ibs.bootappsecure.dto.KycDetailsOutputDto;
import com.wf.ibs.bootappsecure.dto.ServiceProviderOutputDto;
import com.wf.ibs.bootappsecure.entity.Customer;
import com.wf.ibs.bootappsecure.entity.Kyc;
import com.wf.ibs.bootappsecure.entity.ServiceProvider;
import com.wf.ibs.bootappsecure.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService{

	//injecting a dependency
	@Autowired
	private CustomerRepository repository;
	
	// utility method
	private CustomerOutputDto convertEntityToOutputDto(Customer customer) {
		CustomerOutputDto customerOutputDto = new CustomerOutputDto();
		
		customerOutputDto.setUci(customer.getUci());
		customerOutputDto.setSysPassword(customer.getSysPassword());
		customerOutputDto.setNewPassword(customer.getNewPassword());
		
		return customerOutputDto;
	}
	
	private Customer convertPwdResetInputDtoToEntity(IBSResetPwdInputDto resetPwdInputDto) {
		Customer cust = new Customer();
		cust.setNewPassword(resetPwdInputDto.getNewPassword());
		cust.setSysPassword(resetPwdInputDto.getNewPassword());
		
		return cust;
	}
	
	/*private Customer convertKycOutputDtoToEntity(KycDetailsOutputDto kycUpdatedOutputDto) {
		Customer cust = new Customer();
		cust.setKyc(kycUpdatedOutputDto.getKycId());
		cust.setSysPassword(sysPassword);
		
		return cust;
	}*/
	
	private AdminKycIdOutputDto convertEntityToAdminOutput(Customer newCust) {
		
		AdminKycIdOutputDto adminOutputDto = new AdminKycIdOutputDto();
		adminOutputDto.setKycId(newCust.getKycId().getKycId());
		adminOutputDto.setUci(newCust.getUci());
		adminOutputDto.setSysPassword(newCust.getSysPassword());
		
		return adminOutputDto;
	}
	
	
	@Override
	public CustomerOutputDto fetchSingleCustomer(Long uci) {
		System.out.println("uci= "+uci);
		if(this.repository.existsById(uci)) {
			Customer customer = this.repository.findById(uci).orElse(null);
			CustomerOutputDto customerOutputDto = this.convertEntityToOutputDto(customer);
			return customerOutputDto;
		}
		return null;
	}

	@Override
	public CustomerOutputDto updatePwd(Long uci, IBSResetPwdInputDto resetPwdInputDto) {
		if(this.repository.existsById(uci)) {
			// convert input dto into entity
			Customer cust = this.convertPwdResetInputDtoToEntity(resetPwdInputDto);
			// assign the id to employee
			cust.setUci(uci);
			// save into DB, returns newly added record
			// save : PK (id) is null or empty:insert or else update
			Customer newCust = this.repository.save(cust);
			// convert entity into dto
			CustomerOutputDto custOutputDto =  this.convertEntityToOutputDto(newCust);
			return custOutputDto;
		}
		return null;
	}

	@Override
	public AdminKycIdOutputDto saveCustDetails(KycDetailsOutputDto kycUpdatedOutputDto) {
		//convert kycUpdatedOutputDto to entity
		Kyc kyc = new Kyc();
		kyc.setKycId(kycUpdatedOutputDto.getKycId());
		
		//joining kyc id to customer table
		Customer cust = new Customer();
		cust.setKycId(kyc);
		//cust.setKycId(kyc.getKycId());
		
		//save customer data
		Customer newCust = this.repository.save(cust);
		AdminKycIdOutputDto adminOutputDto = this.convertEntityToAdminOutput(newCust);
		
		return adminOutputDto;
		
		
		/*// convert dto into entity
		
		ServiceProvider sp = this.convertInputDtoToEntity(spInputDto);
		// save into DB, returns newly added record
		ServiceProvider newSp = this.repository.save(sp);
		// convert entity into dto
		ServiceProviderOutputDto spOutputDto =  this.convertEntityToOutputDto(newSp);
		return spOutputDto;*/
	}

}
